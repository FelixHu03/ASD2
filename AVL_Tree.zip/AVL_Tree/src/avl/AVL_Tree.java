package avl;

class AvlNode <AnyType>{
	AnyType element;
	AvlNode <AnyType> left, right;
	int height;
	AvlNode(AnyType element, AvlNode<AnyType> left, AvlNode<AnyType> right){
		this.element = element;
		this.left = left;
		this.right = right;
	}
	public String toString() {
		return left + " " + right;
	}
	
}

class AvlTree<AnyType extends Comparable<? super AnyType>> {
	private AvlNode <AnyType> root;
	public AvlTree () {
		root = null;
	}
//	untuk mengukur tinggi
	private int height (AvlNode <AnyType> t) {
		return t == null ? -1 : t.height;
	}
	
//	Method balance factor
	private int maks (int lhs, int rhs) {
		if(lhs > rhs) {
			return lhs;
		}
		return rhs;
	}
	
	private AvlNode<AnyType> case1 (AvlNode<AnyType> k2) {
		AvlNode<AnyType> k1 = k2.left;
		
		k2.left = k1.right;
		k1.right = k2;
		
		k2.height = maks(height(k2.right), height(k2.right)) + 1 ;
		k1.height = maks(height(k1.right), height(k1.right)) + 1 ;
		
		return k1;
	}
	private AvlNode<AnyType> case4 (AvlNode<AnyType> k1){
		AvlNode<AnyType> k2 = k1.right;
		
		k1.right = k2.left;
		k2.left = k1;
		
		k2.height = maks(height(k2.right), height(k2.right)) + 1 ;
		k1.height = maks(height(k1.right), height(k1.right)) + 1 ;
		
		return k2;
		
	}
	private AvlNode<AnyType> case2 (AvlNode<AnyType> k3){
		k3.left = case4(k3.left); // rotasi ke arah kiri
		return case1(k3); // rotasi ke arah Kanan
	}
	
	private AvlNode<AnyType> case3 (AvlNode<AnyType> k1){
		k1.right = case1(k1.right); // rotasi ke arah kanan
		return case4(k1); // rotasi ke arah kiri
	}
	
	private AvlNode<AnyType> insert (AnyType x, AvlNode<AnyType> t){
		if (t == null) {
			t = new AvlNode(x, null, null);
		}
//		case 1 dan 2
		else if (x.compareTo(t.element) < 0) {
			t.left = insert(x, t.left);
			if (height(t.left) - height(t.right) > 1) { //lh
				if (x.compareTo(t.left.element) < 0) { //lh
					t = case1(t);
				}
				else { //rh
					t = case2(t);
				}
			}
		}
//		case 3 dan 4
		else if (x.compareTo(t.element) > 0) {
			t.right = insert(x, t.right);
			if (height(t.right) - height(t.left) > 1 ) { //rh
				if (x.compareTo(t.right.element) > 1) { //rh
					t = case4(t);
				}
				else {//lh
					t = case3(t);
				}
			}
		}
		t.height = maks(height(t.left), height(t.right)) + 1;
		return t;
		
	}
	public void insert(AnyType x) {
		root = insert(x, root);
	}
//	tambahkan method inorder, preorder, dan postorder
	private void inOrder (AvlNode <AnyType> t) {
		if (t != null) {
			if (t.left != null) {
				inOrder(t.left);
			}
			System.out.print(t.element + " ");
			if (t.right != null) {
				inOrder(t.right);
			}
			
		}
	}
	
//	preorder
	private void preOrder (AvlNode <AnyType> t) {
		if (t != null) {
			System.out.print(t.element + " ");
			if (t.left != null) {
				preOrder(t.left);
			}
			if (t.right != null) {
				preOrder(t.right);
			}
		}
	}
	
//	postOrder
	private void postOrder( AvlNode <AnyType> t) {
		if (t != null) {
			if (t.left != null) {
				postOrder(t.left);
			}
			if (t.right != null) {
				postOrder(t.right);
			}
			System.out.print(t.element + " ");
		}
	}
	public void inOrder() {
		this.inOrder(root);
	}
	public void preOrde() {
		this.preOrder(root);
	}
	public void postOrder() {
		this.postOrder(root);
	}
}

public class AVL_Tree {

	public static void main(String[] args) {
//		insert : 10, 85, 15,70,20,60, 30, 
//		50, 65, 80, 90, 40, 5, 55

		AvlTree<Integer> avl = new AvlTree<Integer>();
		
		avl.insert(10);
		avl.insert(85);
		avl.insert(15);
		avl.insert(70);
		avl.insert(20);
		avl.insert(60);
		avl.insert(30);
		avl.insert(50);
		avl.insert(65);
		avl.insert(80);
		avl.insert(90);
		avl.insert(40);
		avl.insert(5);
		avl.insert(55);
		
		System.out.println("InOrder =  ");
		avl.inOrder();
		System.out.println("\npreOrder =  ");
		avl.preOrde();
		System.out.println("\nPostOeder =  ");
		avl.postOrder();
	}

}
